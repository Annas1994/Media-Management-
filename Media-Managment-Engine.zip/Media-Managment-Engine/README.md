# Media-Managment-Engine
This is an image processing project. It uses Microsoft FACE api.

Front End:
HTML
CSS
JavaScript
AngularJS

Backend:
Firebase
NodeJS

Dependencies:

Project Oxford for image processing

This project has user login and signup module

It does image processing based using face api from microsoft.



